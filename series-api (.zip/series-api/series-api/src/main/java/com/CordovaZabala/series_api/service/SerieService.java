package com.CordovaZabala.series_api.service;

import com.CordovaZabala.series_api.models.Serie;
import com.CordovaZabala.series_api.repository.SerieRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SerieService {

    @Autowired
    private SerieRepository serieRepository;

    public List<Serie> obtenerTodas() {
        return serieRepository.findAll();
    }

    public Optional<Serie> obtenerPorId(Long id) {
        return serieRepository.findById(id);
    }

    public Serie guardar(Serie serie) {
        return serieRepository.save(serie);
    }

    public Optional<Serie> actualizar(Long id, Serie serieDetalles) {
        return serieRepository.findById(id).map(serie -> {
            serie.setTitulo(serieDetalles.getTitulo());
            serie.setPlataforma(serieDetalles.getPlataforma());
            serie.setCalificacion(serieDetalles.getCalificacion());
            return serieRepository.save(serie);
        });
    }

    public boolean eliminar(Long id) {
        if (serieRepository.existsById(id)) {
            serieRepository.deleteById(id);
            return true;
        }
        return false;
    }
}