package com.CordovaZabala.series_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeriesApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
